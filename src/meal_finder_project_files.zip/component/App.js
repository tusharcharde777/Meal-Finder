import '../style/App.css'
// import Meal from './Meal';
import Meal2 from "./Meal2";
import '../style/style.css'

function App() {
  return (
    <div className="App">
      <Meal2 />
      {/* <h1>Welcome</h1>
      <Meal /> */}
    </div>
  );
}

export default App;
