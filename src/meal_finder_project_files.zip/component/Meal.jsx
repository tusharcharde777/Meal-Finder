// import React from "react";

// class Meal extends React.Component {
//   constructor() {
//     super();
//     this.state = {
//       users: null,
//     };
//   }
//   componentDidMount() {
//     fetch(`https://www.themealdb.com/api/json/v1/1/search.php?s=curry`).then(
//       (response) => {
//         response.json().then((result) => {
//           console.log(result.meals)
//         //   this.setState({ users: result.data });
//         });
//       }
//     );
//   }
//   render() {
//     return (
//       <div>
//         <h1>Fetch data</h1>

//         {/* {this.state.users
//           ? this.state.users.map((item) => (
//               <div>
//                 <p>{item.idMeal}</p>
//               </div>
//             ))
//           : null} */}
//       </div>
//     );
//   }
// }

// export default Meal;
